const axios = require('axios');
const crypto = require('crypto');

module.exports = async (req, res) => {
  const { name, email, amount, bundle } = req.body;

  const orderData = {
    order_id: `order_${Date.now()}`,
    order_amount: amount,
    order_currency: "INR",
    customer_details: {
      customer_id: email,
      customer_name: name,
      customer_email: email,
      customer_phone: "9999999999", // Replace if available
    },
    order_meta: {
      return_url: "https://innovativegraphic.vercel.app/thank-you?order_id={order_id}",
    },
  };

  try {
    const response = await axios.post(
      "https://sandbox.cashfree.com/pg/orders",
      orderData,
      {
        headers: {
            "x-client-id": process.env_94658785481224c4d1789bd633785649,
            "x-client-secret": process.env.cfsk_ma_prod_6b5c4eed5aa7f57ca5dca5b6693ab23b_e59c5ef8,
          "x-api-version": "2022-09-01",
        },
      }
    );

    res.json({
      orderId: response.data.order_id,
      paymentSessionId: response.data.payment_session_id,
    });
  } catch (error) {
    console.error("Cashfree API error:", error.response?.data || error.message);
    res.status(500).json({ error: "Payment failed. Please try again." });
  }
};