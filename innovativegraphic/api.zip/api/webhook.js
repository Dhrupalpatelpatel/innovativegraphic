const crypto = require('crypto');

module.exports = async (req, res) => {
  const signature = req.headers['x-cf-signature'];
  const body = JSON.stringify(req.body);

  // Verify signature
  const expectedSignature = crypto
    .createHmac('sha256', process.env.cfsk_ma_prod_6b5c4eed5aa7f57ca5dca5b6693ab23b_e59c5ef8)
    .update(body)
    .digest('base64');

  if (signature !== expectedSignature) {
    return res.status(401).json({ error: "Invalid signature" });
  }

  // Payment success logic (update database, send email, etc.)
  console.log("💰 Payment succeeded:", req.body.order_id);
  res.status(200).end();
};